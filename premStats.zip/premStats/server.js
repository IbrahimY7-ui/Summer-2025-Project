const express = require('express');
const mongoose = require('mongoose');
const app = express();
const path = require('path');
const Player = require('./Player');

const uri = "mongodb+srv://IbrahimYousuf:testing123@cluster0.gjvqzej.mongodb.net/PremierLeague?retryWrites=true&w=majority&appName=Cluster0";



app.use(express.static(path.join(__dirname, 'public')));

app.get("/", (req, res) => {
  console.log("here");
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get("/players", async (req, res) => {
  try {
    const players = await Player.find();
    res.json(players);
  } catch (err) {
    console.error("DB error:", err);
    res.status(500).json({ error: "Could not fetch players" });
  }
});


app.listen(3000, () => console.log('Server started on http://localhost:3000'));

const connectDB = async () => {
  try {
    await mongoose.connect(uri, {
     
    });

    console.log("Connected to MongoDB");
    app.listen(3000, () => {
      console.log("Server running on http://localhost:3000");
    });

  } catch (err) {
    console.error("MongoDB connection error:", err);
  }
};

connectDB();
